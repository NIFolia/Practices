#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "mpi.h"

double factorial(double num);
double power(double base, double exp);

int main(int argc, char *argv[])
{
     int my_id,i,p;
     double fNum, pnum, divisor;
     double a, s;
     MPI_Status status;
     MPI_Init(&argc,&argv);
     MPI_Comm_rank(MPI_COMM_WORLD,&my_id);
     MPI_Comm_size(MPI_COMM_WORLD,&p);
     if (my_id==0)
     {
          a=30.0;
          for (i=0;i<p;i++)
          {
               MPI_Send(&a,1,MPI_DOUBLE,i,0,MPI_COMM_WORLD);
          }
     }
     MPI_Recv(&a,1,MPI_DOUBLE,0,0,MPI_COMM_WORLD,&status);
     if (my_id==0)
     {
         fNum = factorial(3.0);
         pnum = power(a,3.0);
         s=a-pnum/fNum;
         MPI_Send(&s,1,MPI_DOUBLE,1,0,MPI_COMM_WORLD);
     }
     if (my_id>0)
     {
          MPI_Recv(&s,1,MPI_DOUBLE,my_id-1,0,MPI_COMM_WORLD,&status);
          divisor = (double)((2.0*(double)my_id)+3.0);
          fNum = factorial(divisor);
          pnum = power(a,(divisor));
          if (my_id%2==0)
          {
               s=s-pnum/fNum;
          }
          else
          {
               s=s+pnum/fNum;
          }
          MPI_Send(&s,1,MPI_DOUBLE,(my_id+1)%p,0,MPI_COMM_WORLD);
     }
     if (my_id==0)
     {
          MPI_Recv(&s,1,MPI_DOUBLE, p-1,0,MPI_COMM_WORLD,&status);
          printf("The sin of %lf is  %lf\n",a,s);
     }
     MPI_Finalize();
}

double factorial(double num)
{
     double factNum = 1.0;
     while(num > 0.0)
     {
          factNum = factNum*num;
          num--;
     }
     return factNum;
}

double power(double base, double exp)
{
     double powerNum = 1.0;
     while(exp > 0.0)
     {
          powerNum = powerNum*base;
          exp--;
     }
     return powerNum;
}
